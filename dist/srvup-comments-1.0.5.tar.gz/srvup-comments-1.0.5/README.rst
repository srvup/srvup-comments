Srvup Comments
=====

A reusable Django & Javascript app (jQuery) for simply implementing a comments feed on any url. Go here to get started: https://github.com/srvup/srvup-comments

